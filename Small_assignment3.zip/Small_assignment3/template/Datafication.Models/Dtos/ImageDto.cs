namespace Datafication.Models.Dtos
{
    public class ImageDto
    {
        public int Id { get; set; }
        public string Url { get; set; }
    }
}