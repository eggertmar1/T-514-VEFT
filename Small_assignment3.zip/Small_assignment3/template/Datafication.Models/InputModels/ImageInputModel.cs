namespace Datafication.Models.InputModels
{
    public class ImageInputModel
    {
        public string Url { get; set; }
        public int IceCreamId { get; set; }
    }
}