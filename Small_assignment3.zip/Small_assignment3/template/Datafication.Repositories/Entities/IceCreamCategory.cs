using System.Collections.Generic;
namespace Datafication.Repositories.Entities
{
    public class IceCreamCategory
    {
        public int IceCreamsId { get; set; }
        public int CategoriesId { get; set; }
    }
}