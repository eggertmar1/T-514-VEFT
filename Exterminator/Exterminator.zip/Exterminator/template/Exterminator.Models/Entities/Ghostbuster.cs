namespace Exterminator.Models.Entities
{
    public class Ghostbuster
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Expertize { get; set; }
    }
}