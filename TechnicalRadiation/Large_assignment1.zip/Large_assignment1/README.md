# Large_assignment1

## To add a package
``` dotnet add package <PackageName>``` 

## To migrate the database
``` dotnet ef migrations add <MigrationName> ```

## To update database
``` dotnet ef database update ```

## Password
```Key: Authorization, Value: root beer```

